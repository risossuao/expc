$(document).ready(function () {

    $("#bCadastrar").click(function () {

        window.location.href = "cadastro.html";
    });


    $("#bEntrar").click(function () {
        console.log("iniciando");

        _usuario = document.getElementById("tUsuario").value;
        senha = document.getElementById("tSenha").value;

        if (_usuario.length == 0 || senha.length == 0) {
            alert('campos em branco');
        } else {
            localStorage.setItem('user', _usuario);

            myBitArray = sjcl.hash.sha256.hash(senha); //hash da senha
            _senha = sjcl.codec.hex.fromBits(myBitArray);

            $.ajax({ //ajax faz a conexao do front pro back

                type: "POST",
                dataType: "json",
                url: "../php/login.php",
                async: false,

                data: {
                    usuario: _usuario,
                    senha: _senha,
                },

                success: function (data) {
                    console.log(data);
                    if (data == "success") {
                        window.location.href = "../paginas/confirma_login.html";

                    } else if (data.status == 'error') {
                        alert("usuario ou senha invalido");
                    }
                },

                error: function (data) {

                    console.log('error');
                    if (data == "success") {
                        window.location.href = "../paginas/confirma_login.html";

                    } else if (data.status == "error") {
                        alert("usuario ou senha invalido");
                    }
                },

            });
        }
    });
});

