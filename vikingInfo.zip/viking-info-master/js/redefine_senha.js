$(document).ready(function () {

    $("#bSalvar").click(function () {

        senha = $("#tSenha").val().trim();
        c_senha = $("#tConfirmarSenha").val().trim();

        if (senha == "" || c_senha == "") {
            //alert("Preencha com seu email");
            $("div#mensagem").html("Preencha todos os campos!");
        } else if (senha == c_senha) {
            var myBitArray = sjcl.hash.sha256.hash(senha);
            var senha = sjcl.codec.hex.fromBits(myBitArray);

            $.ajax({
                type: "POST",
                dataType: "json",
                url: "../php/redefine_senha.php",
                async: false,
                data: {
                    senha: senha,
                },
                success: function (retorno) {
                    console.log(retorno);

                    if (retorno["erro"]) {
                        //alert(retorno["mensagem"]);
                        $("div#mensagem").html(retorno["mensagem"]);
                    } else {
                        //alert(retorno["mensagem"]);
                        window.location = "../paginas/login.html";
                    }
                },
                error: function (retorno) {
                    console.log(retorno);
                    //alert(retorno["mensagem"]);
                    $("div#mensagem").html("Erro durante a solicitação!");
                }
            });
        }
    });
})