$(document).ready(function(){
        var email = localStorage.getItem('email');
        
        var x = document.getElementById("email");
        x.innerHTML = email;

        //alert(email);
	
	$("#confirmar").click(function(){
                _token = $("input[name=token]").val();
                _email = email;

                //alert(_email);
                //alert(_token);
                
                $.ajax({ //ajax faz a conexao do front pro back
                        type: "POST",
                        dataType: "json",
                        url: "../php/confirma_cadastro.php",
                        async: false,
                        data: {
                                token: _token,
                                email: _email,
                        },

                        success: function(data){  
                                console.log(data);
                                if (data == 'success') {
                                        alert("cadastrado com sucesso");
                                        window.location.href =  "../paginas/login.html";
                                }else{
                                        alert("erro no token 1")
                                }

                        },
                        error: function(data){   
                                console.log(data);   
                                if (data == 'success') {
                                        alert("cadastrado com sucesso");
                                        window.location.href =  "../paginas/login.html";
                                }else{
                                        alert("erro no token 2")
                                }
                               
                        },
                        
                })
	});

});
