$(document).ready(function () {

    $("#esqueci_senha").click(function () {

        email = $("#tEmail").val().trim();
        if (email == "") {
            //alert("Preencha com seu email");
            $("div#mensagem").html("Preencha o campo de email!");
        } else {
            $.ajax({
                type: "POST",
                dataType: "json",
                url: "../php/esqueci_senha.php",
                async: false,
                data: {
                    email: email,

                },
                success: function (retorno) {
                    //console.log(retorno);

                    if (retorno["erro"]) {
                        //alert(retorno["mensagem"]);
                        $("div#mensagem").html(retorno["mensagem"]);
                    } else {
                        //alert(retorno["mensagem"]);
                        window.location = "../paginas/esqueci_token.html";
                    }
                },
                error: function (retorno) {
                    //console.log(retorno);
                    //alert(retorno["mensagem"]);
                    $("div#mensagem").html("Erro durante a solicitação!");
                }
            });
        }
    });

});



//<h2 id="email_token" name="email_token"> </h2><br></br>