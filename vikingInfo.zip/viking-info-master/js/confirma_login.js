$(document).ready(function () {
    var user = localStorage.getItem('user');

    var x = document.getElementById("user");
    x.innerHTML = user;

    function setUsuarioLogado(user) {
        localStorage.setItem("usuario_logado", JSON.stringify(user));
    }

    $("#confirmar").click(function () {
        
        _user = user;
        _token = $("#token").val().trim();

        if (_token == "") {
            alert("Insira um token valido");
        } else {

            $.ajax({ //ajax faz a conexao do front pro back
                type: "POST",
                dataType: "json",
                url: "../php/confirma_login.php",
                async: false,
                data: {
                    token: _token,
                    user: _user,
                },


                success: function (data) {
                    alert(data["user"]);
                    if (data["erro"] == 1) {
                        alert(data["mensagem"]);
                        //$("div#mensagem").html(data["mensagem"]);
                        window.location.href = "../paginas/login.html";
                    } else {
                        alert('usuario logado com sucesso');
                        setUsuarioLogado(data["user"]);
                        window.location.href = "../index.html";
                        //alert('ok');
                    }
                },

                error: function (data) {
                    alert(data);
                    if (data["erro"] == 0) {
                        alert('usuario logado com sucesso');
                        setUsuarioLogado(data);
                        window.location.href = "../index.html";

                    } else {
                        alert("erro com o token");
                        window.location.href = "../paginas/login.html";
                    }
                },
            });
        }
    });
});