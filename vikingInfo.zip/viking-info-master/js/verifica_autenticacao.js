$(document).ready(function () {

  //$usuario = localStorage.getItem("user");

  $.ajax({ //ajax faz a conexao do front pro back
    type: "POST",
    dataType: "json",
    url: "../php/verifica_autenticacao.php",
    async: false,

    success: function (retorno) {
      if (retorno["erro"] == 2) {
        //alert(retorno["mensagem"]);
        window.location.href = "../paginas/login.html";
      } else if (retorno["erro"] == 1) {
        //alert(retorno["mensagem"]);
        localStorage.removeItem("usuario_logado");
        window.location.href = "../paginas/login.html";
      }
    },

    error: function (retorno) {
      if (retorno["erro"] == 2) {
        //alert(retorno["mensagem"]);
        window.location.href = "../paginas/login.html";
      } else if (retorno["erro"] == 1) {
        //alert(retorno["mensagem"]);
        //localStorage.removeItem("usuario_logado");
        window.location.href = "../paginas/login.html";
      }
    },
  });

});