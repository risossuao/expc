window.onload = function () {
    let formCadastro = document.querySelector(".formCadastro");
    formCadastro.addEventListener('submit', cadastrar);
    let tSenha = document.querySelector("#tSenha");
    tSenha.addEventListener('keyup', verifica);


function cadastrar(event){

    event.preventDefault();
    console.log("Iniciando cadastro");
    let nome = document.getElementById("tNome").value; 
    let sobrenome = document.getElementById("tSobrenome").value;
    let email = document.getElementById("tEmail").value;
    let usuario = document.getElementById("tUsuario").value;
    let senha = document.getElementById("tSenha").value;
    let confirmarSenha = document.getElementById("tConfirmarSenha").value;
    email = document.getElementById("tEmail").value;
    
    localStorage.setItem('email', email);
    localStorage.setItem("user", usuario);
    
    let novoUsuario = {
            nome: nome, 
            sobrenome: sobrenome,
            email: email,
            usuario: usuario,
            senha: senha,
            carrinho: []
    }
    
    
    if(validaUsuario(novoUsuario, confirmarSenha)){
        //Cadastro permitido
        var myBitArray = sjcl.hash.sha256.hash(novoUsuario.senha);
        var senha_sha256 = sjcl.codec.hex.fromBits(myBitArray);
        novoUsuario.senha = senha_sha256;
        executarCadastro(novoUsuario);        
        return false;
        
    }
}

function validaUsuario(novoUsuario, confirmarSenha){
    if(validaSenha(novoUsuario.senha, confirmarSenha)){

    }else{
        alert("Senha errada");
        return false;
    } //eu poderia colocar apenas um ! na frente do validaSenha, q iria fazer a mesma função

    if(validaDadosEmBranco(novoUsuario)){

    }else{
        alert("Campos em branco");
        return false;
    }

    if(verificaSenhaForte(novoUsuario.senha)){

    }else{
        alert("Senha Fraca");
        return false;
    }

    return true;
}


function validaSenha(senha, confirmarSenha){

    if(senha === confirmarSenha){
        return true;
    
    }

    return false;

}

function validaDadosEmBranco(novoUsuario){
    if(novoUsuario.nome.trim().length === 0){ //a função trim tira todos os espaços em branco; Remove whitespace from both sides of a string
        return false;
    }

    if(novoUsuario.sobrenome.trim().length === 0){
        return false;
    }

    if(novoUsuario.email.trim().length === 0){
        return false;
    }

    if(novoUsuario.usuario.trim().length === 0){
        return false;
    }

    if(novoUsuario.senha.trim().length === 0){
        return false;
    }

    return true;
}

function executarCadastro(novoUsuario){
    //alert('oi');
    $.ajax({ //ajax faz a conexao do front pro back
		type: "POST",
		dataType: "json",
		url: "../php/cadastro.php",
        async: false,
		data: {
            nome: novoUsuario.nome, 
            sobrenome: novoUsuario.sobrenome,
            email: novoUsuario.email,
            usuario: novoUsuario.usuario,
            senha: novoUsuario.senha,
        },

		success: function(data){  
            //alert('1');
            console.log(data);
            if(data == 'success'){
                window.location.href =  "../paginas/confirma_cadastro.html";

            }else if(data == 'error'){
                alert("email ou usuario já em uso");
            }
		},

        error: function(data){
            //alert('2');
            console.log(data);
            if(data == 'success'){
                window.location.href =  "../paginas/confirma_cadastro.html";

            }else if(data == 'error'){
                alert("email ou usuario já em uso");
            }
        }
	})
    return;
}
//mudar verificação de senha forte

function verifica(){ //calcula forca senha
    console.log("verifica");
    senha = document.getElementById("tSenha").value;
    forca = 30;
    mostra = document.getElementById("mostra");
    if((senha.length >= 4) && (senha.length <= 7)){
        forca += 10;
    }else if(senha.length>7){
        forca += 25;
    }
    if(senha.match(/[a-z]+/)){
        forca += 10;
    }
    if(senha.match(/[A-Z]+/)){
        forca += 20;
    }
    if(senha.match(/d+/)){
        forca += 20;
    }
    if(senha.match(/W+/)){
        forca += 25;
    }
    return mostra_res(mostra, forca);
}
function mostra_res(mostra, forca){ //mostra forca senha
    if(forca < 30){
        mostra.innerHTML = '<tr><td bgcolor="red" width="'+forca+'"></td><td>Fraca </td></tr>';
    }else if((forca >= 30) && (forca < 60)){
        mostra.innerHTML = '<tr><td bgcolor="yellow" width="'+forca+'"></td><td>Justa </td></tr>';;
    }else if((forca >= 60) && (forca < 85)){
        mostra.innerHTML = '<tr><td bgcolor="blue" width="'+forca+'"></td><td>Forte </td></tr>';
    }else{
        mostra.innerHTML = '<tr><td bgcolor="green" width="'+forca+'"></td><td>Excelente </td></tr>';
    }
}

function verificaSenhaForte(senha){ //calcula forca senha
    forca = 30;
    if((senha.length >= 4) && (senha.length <= 7)){
        forca += 10;
    }else if(senha.length>7){
        forca += 25;
    }
    if(senha.match(/[a-z]+/)){
        forca += 10;
    }
    if(senha.match(/[A-Z]+/)){
        forca += 20;
    }
    if(senha.match(/d+/)){
        forca += 20;
    }
    if(senha.match(/W+/)){
        forca += 25;
    }

    if(forca >= 0 && forca < 40 ){
        return false;
    }else if(forca >= 40){
        return true;
    }
}

};