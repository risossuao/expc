$(document).ready(function () {

    fn_local_eventos_click();
});

function fn_local_eventos_click() {
    $("#bEnviarToken").click(function () {

        fLocalEnviaToken();

    });

};

function fLocalEnviaToken() {

    token = $("#tToken").val().trim();
    if (token == "") {
        //alert("Preencha com seu token");
        $("div#mensagem").html("Preencha o campo de token!");
    } else {
        $.ajax({
            type: "POST",
            dataType: "json",
            url: "../php/esqueci_token.php",
            async: false,
            data: {
                token: token,
            },
            success: function (retorno) {
                console.log(retorno);

                if (retorno["erro"]) {
                    //alert("token errado");
                    $("div#mensagem").html(retorno["mensagem"]);
                } else {
                    //alert("token correto");
                    window.location = "../paginas/redefine_senha.html";

                }
            },
            error: function (retorno) {
                console.log(retorno);
                $("div#mensagem").html("Erro durante a solicitação!");
            },
        })
    }
}



