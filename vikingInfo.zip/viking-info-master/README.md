Nota: trabalho atualmente sendo editado para a disciplina de experiência criativa - 3° período.

Trabalho realizado e apresentado em grupo (11/2020) a disciplina de programação web ministrada pelo professor doutor Jose Eduardo Nunes Lino, durante curso de segurança da informação/cibersegurança - PUCPR - 2° período.
 
objetivos: criar um site do zero respeitando algumas exigências. Em sua ideia central o site é uma loja fictícia que vende produtos de informática para o uso durante a quarentena.    

Proposito: trabalho final da disciplina para avaliar os conhecimentos nas linguagens ministradas durante as aulas: html, css, Java script (jquery) e  Git, através do terminal para o versionamento do site.  


