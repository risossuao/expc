<?php
session_start();

$tempoDeSegParaMin = 60;
$tempoMinutos = 0 * $tempoDeSegParaMin;
$tempoSegundos = 2 + $tempoMinutos;
$tempo1Hora = 60 * 60;

if (isset($_SESSION["inicioDaSessao"])) {
	$tempoLimite = time() - $_SESSION["inicioDaSessao"];
	$tempoLimite1Hora = time() - $_SESSION["sessaoRf9"];
	if ($tempoLimite >= $tempoSegundos || $tempoLimite1Hora >= $tempo1Hora) {
		echo json_encode(array("erro" => 1, "mensagem" => "Sessao expirou"));
		unset($_SESSION["id"]);
		unset($_SESSION["usuario"]);
		unset($_SESSION["inicioDaSessao"]);
		unset($_SESSION["sessaoRf9"]);
		session_destroy();
	}
} else if (isset($_SESSION["id"]) == false) {
	echo json_encode(array("erro" => 2, "mensagem" => "Nao ha usuario logado"));
}

$_SESSION["inicioDaSessao"] = time();
