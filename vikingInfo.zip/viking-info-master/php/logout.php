<?php
	error_reporting(E_ALL);
	ini_set('display_errors', 'On');
	session_start();

	unset($_SESSION["id"]);
    unset($_SESSION["usuario"]);

    unset($_SESSION["inicioDaSessao"]);
    unset($_SESSION["sessaoRf9"]);

	session_destroy();

	if (isset($_SESSION["id"]) == false) {
		$response_array["status"] = "n"; 
		
        
	}else{
		$response_array["status"] = "s"; 
		
	}
	echo json_encode($response_array);

?>