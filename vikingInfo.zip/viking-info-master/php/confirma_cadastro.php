<?php
    //error_reporting(E_ALL);
    ini_set('display_errors', 'On');
    require 'config.php';
    header('Content-type: application/json');

    $token_user = $_POST["token"];
    $email = $_POST["email"];

    $sql_consulta =  "SELECT * FROM desafio WHERE email = '$email'";
    $mysqli = mysqli_query($con, $sql_consulta);
    
    while ($linha = mysqli_fetch_assoc($mysqli)){
     
            $token_bd = strtoupper($linha["token"]);
            
            if($token_bd == strtoupper($token_user)){
     
                mysqli_query($con, "UPDATE desafio SET status_token = 1 WHERE email = '$email'");
                $response_array = 'success';
                echo json_encode($response_array);
                 
            } else{

                mysqli_query($con, "DELETE FROM desafio WHERE email = $email");
                $response_array = 'error'; 
                echo json_encode($response_array);
            }
             
    };
