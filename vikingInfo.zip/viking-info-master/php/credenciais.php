<?php
define('EMAIL','vikinginfo.ec@gmail.com');
define('PASS','pucpr321');

//define('EMAIL','recoverexpcriat@gmail.com');
//define('PASS','pucpr2021');
?>