<?php
header('Content-type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 'On');

require "config.php"; //configuracao do banco sql
require "credenciais.php"; //login e senha do email de envio

function email($email, $token, $nome)
{
    ini_set('display_errors', 'On');
    require "../PHPMailer/PHPMailerAutoload.php";
    date_default_timezone_set('Etc/UTC');
    require_once "credenciais.php";
    $file = file_get_contents("../templates/t_esqueci_senha.html");
    $file = str_replace("[NOME_USUARIO]", $nome, $file);
    $file = str_replace("[TOKEN]", $token, $file);

    $output = $file;

    $mail = new PHPMailer;
    $mail->IsSMTP();
    $mail->isHTML(true);
    $mail->CharSet = 'UTF-8';
    $mail->SMTPDebug = 0;       // 0 = nao mostra o debug, 2 = mostra o debug
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'ssl';
    $mail->Host = 'smtp.gmail.com';

    $mail->Port = 465;
    $mail->Username = EMAIL;
    $mail->Password = PASS;

    $mail->SingleTo = true;

    $mail->SetFrom(EMAIL, 'Localhost');
    $mail->FromName = "Equipe Viking Info";
    $mail->addAddress($email);
    $mail->isHTML(true);

    $mail->Subject = 'Token de senha esquecida';
    $mail->Body    = $output;

    if (!$mail->send()) {
        echo json_encode(array("erro" => 1, "mensagem" => "Erro ao enviar email!"));
    }

    //echo json_encode(array("erro" => 0, "mensagem" => "Email enviado com sucesso!"));

}

$token = '';
$nome = '';
$email = mysqli_real_escape_string($con, $_POST['email']);


$sql_email = "SELECT * FROM desafio WHERE email = '$email'"; //consulta do banco
$sql_token = "SELECT * FROM desafio WHERE token = '$token'";

if (isset($_POST['email']) && $con != null) {
    $mysqli = mysqli_query($con, $sql_email);
    if (mysqli_num_rows($mysqli) == 1) {
        while ($linha = mysqli_fetch_array($mysqli)) {
            $nome = $linha["nome"];
            while (true) {
                $t = openssl_random_pseudo_bytes(3);
                $token = strtoupper(bin2hex($t));
                $mysqli_token = mysqli_query($con, $sql_token);
                if (mysqli_num_rows($mysqli_token) <= 0) {
                    session_start();
                    $_SESSION['email_user'] = $email;
                    break;
                }
            }
            email($email, $token, $nome);
            $u_token = "UPDATE desafio SET token = '$token' WHERE email = '$email'";
            $mysqli_1 = mysqli_query($con, $u_token);

            echo json_encode(array("erro" => 0, "mensagem" => "Email existente!"));
        }
    } else {
        echo json_encode(array("erro" => 1, "mensagem" => "Email inexistente!"));
    }
}
