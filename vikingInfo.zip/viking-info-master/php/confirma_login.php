<?php
error_reporting(E_ALL);
ini_set('display_errors', 'On');
require 'config.php';

$user = $_POST["user"];
$token_user = $_POST["token"];

$mysqli = mysqli_query($con, "SELECT * from desafio where usuario LIKE '$user'");

if ($mysqli) {
    while ($linha = mysqli_fetch_assoc($mysqli)) {

        $token_bd = strtoupper($linha["token"]);

        if ($token_bd == strtoupper($token_user)) {
            echo json_encode(array("user" => $user));

            //inicio da sessão 
            session_start();

            //variaveis da sessão
            $_SESSION["id"] = session_id();
            $_SESSION["usuario"] = $user;

            $_SESSION["inicioDaSessao"] = time();
            $_SESSION["sessaoRf9"] = time();
            
            //print_r($_SESSION);

        } else {
            echo json_encode(array("erro" => 1, "mensagem" => "Token errado!"));
        }
    };
} else {
    echo json_encode(array("erro" => 1, "mensagem" => "Erro interno no servidor!"));
}
