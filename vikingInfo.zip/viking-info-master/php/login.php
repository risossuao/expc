<?php
//error_reporting(E_ALL);
//ini_set('display_errors', 'On');
require 'config.php';
header('Content-type: application/json');

$usuario = $_POST["usuario"];
$senha = $_POST["senha"];


/*enviar-email.php*/
function email($email, $token)
{

    require '../PHPMailer/PHPMailerAutoload.php';
    require 'credenciais.php';

    $tituloEmail = "token de acesso viking info";

    $mensagem =  strtoupper($token);

    $mail = new PHPMailer;
    $mail->IsSMTP();
    $mail->CharSet = 'UTF-8';
    $mail->SMTPDebug = 0;       // 0 = nao mostra o debug, 2 = mostra o debug
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'ssl';
    $mail->Host = 'smtp.gmail.com';

    $mail->Port = 465;
    $mail->Username = EMAIL;
    $mail->Password = PASS;

    $mail->SetFrom(EMAIL);
    $mail->addAddress($email);
    $mail->Subject = $tituloEmail;
    $mail->IsHTML(true);
    $mail->msgHTML($mensagem);

    $mail->send();
}

//conexao com o banco

$mysqli = mysqli_query($con, "SELECT * from desafio where usuario LIKE '$usuario'");

while ($linha = mysqli_fetch_array($mysqli)) {

    $email = $linha["email"];
    $senha_bd = $linha["senha"];

    if ($senha == $senha_bd) {

        $t = openssl_random_pseudo_bytes(3);
        $token = strtoupper(bin2hex($t));

        email($email, $token);
        mysqli_query($con, "UPDATE desafio SET token = '$token' WHERE email LIKE '$email'");

        $response_array = 'success';
        echo json_encode($response_array);
    } else {

        $response_array = 'error';
        echo json_encode($response_array);
    }
}

/*$texto = utf8_encode(file_get_contents("../templates/if_i_had_a_heart.txt"));

$array_palavras = explode(" ", $texto);

$db_senha_esteganografia = "";

$db_senha_esteganografia .= $array_palavras[7][2]; //v
$db_senha_esteganografia .= $array_palavras[5][3]; //i
$db_senha_esteganografia .= $array_palavras[57][2]; //k
$db_senha_esteganografia .= $array_palavras[5][3]; //i
$db_senha_esteganografia .= $array_palavras[7][0]; //n
$db_senha_esteganografia .= $array_palavras[14][0]; //g
$db_senha_esteganografia .= $array_palavras[5][3]; //i
$db_senha_esteganografia .= $array_palavras[7][0]; //n
$db_senha_esteganografia .= $array_palavras[0][1]; //f
$db_senha_esteganografia .= $array_palavras[12][1]; //o
chave_privada => chave_publica
esteg_chave_secreta => cripto_chave_privada*/