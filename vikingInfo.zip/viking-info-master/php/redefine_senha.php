<?php
session_start();
header('Content-type: application/json; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 'On');

require "config.php";

$email = $_SESSION['email_user'];

$senha = mysqli_real_escape_string($con, $_POST['senha']);

$sql_email = "SELECT * FROM desafio WHERE email = '$email'";
$sql_upsenha = "UPDATE desafio SET senha = '$senha' WHERE email = '$email'";
//$sql_zera_token = "UPDATE desafio SET token = '$token' WHERE email = '$email'";

if (isset($_POST['senha']) && $con != null) {
    $mysqli = mysqli_query($con, $sql_email);
    while ($linha = mysqli_fetch_assoc($mysqli)) {
        $senha_bd = $linha["senha"];
        if ($senha_bd != $senha) {
            $mysqli_up = mysqli_query($con, $sql_upsenha);
            echo json_encode(array("erro" => 0, "mensagem" => "Senha alterada!"));
            session_destroy();
        } else if ($senha_bd == $senha) {
            echo json_encode(array("erro" => 1, "mensagem" => "Nova senha é igual a anterior!"));
        }
    }
} else {
    echo json_encode(array("erro" => 1, "mensagem" => "Erro interno no servidor!"));
}
