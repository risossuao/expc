<?php
session_start();
header('Content-type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 'On');

require "config.php";

$email = $_SESSION['email_user'];
//echo "$email";
$token = mysqli_real_escape_string($con, $_POST['token']);
$sql =  "SELECT * FROM desafio WHERE token = '$token' AND email = '$email'";

if (isset($_POST['token']) && $con != null) {
    $mysqli = mysqli_query($con, $sql);
    if (mysqli_num_rows($mysqli) == 1) {
        echo json_encode(array("erro" => 0, "mensagem" => "Token existente!"));
    } else {
        echo json_encode(array("erro" => 1, "mensagem" => "Token inexistente!"));
    }
} else {
    echo json_encode(array("erro" => 1, "mensagem" => "Erro interno no servidor!"));
}
