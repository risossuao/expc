<?php

$texto = utf8_encode(file_get_contents("../templates/if_i_had_a_heart.txt"));

$array_palavras = explode(" ", $texto);

$db_senha_esteganografia = "";

$db_senha_esteganografia .= $array_palavras[7][2]; //v
$db_senha_esteganografia .= $array_palavras[5][3]; //i
$db_senha_esteganografia .= $array_palavras[57][2]; //k
$db_senha_esteganografia .= $array_palavras[5][3]; //i
$db_senha_esteganografia .= $array_palavras[7][0]; //n
$db_senha_esteganografia .= $array_palavras[14][0]; //g
$db_senha_esteganografia .= $array_palavras[5][3]; //i
$db_senha_esteganografia .= $array_palavras[7][0]; //n
$db_senha_esteganografia .= $array_palavras[0][1]; //f
$db_senha_esteganografia .= $array_palavras[12][1]; //o

$host = "localhost:3307";
$db_login = "root";
$db_senha = $db_senha_esteganografia;
$db_nome = "teste";
//$con = mysqli_connect("localhost" /*porta do mysql*/, "root", "root", "teste");

try {
    $con =  mysqli_connect($host, $db_login, $db_senha, $db_nome);
    return $con;
} catch (Exception $erro) {
    //echo json_encode(array("erro" => 1, "mensagem" => "Erro de conexao: {$erro->connect_errno}"));
    $con = null;
}
