<?php
//require 'config.php';
error_reporting(E_ALL);
ini_set('display_errors', 'On');
//header('Content-type: application/json');

//o php faz a conexao do back com o banco sql

$nome = $_POST["nome"];
$sobre_nome = $_POST["sobrenome"];
$email = $_POST["email"];
$usuario = $_POST["usuario"];
$senha = $_POST["senha"];

$status_token = 0;

date_default_timezone_set('America/Sao_Paulo');
$h = date('h');
$i = date('i');
$hr = $h . $i;

$t = openssl_random_pseudo_bytes(3);
$token = bin2hex($t);

/*enviar-email.php*/
function email($email, $token)
{

    require '../PHPMailer/PHPMailerAutoload.php';
    require 'credenciais.php';

    $tituloEmail = "token de acesso viking info";

    $mensagem =  strtoupper($token);

    $mail = new PHPMailer;
    $mail->IsSMTP();
    $mail->CharSet = 'UTF-8';
    $mail->SMTPDebug = 0;       // 0 = nao mostra o debug, 2 = mostra o debug
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'ssl';
    $mail->Host = 'smtp.gmail.com';

    $mail->Port = 465;
    $mail->Username = EMAIL;
    $mail->Password = PASS;

    $mail->SetFrom(EMAIL);
    $mail->addAddress($email);
    $mail->Subject = $tituloEmail;
    $mail->IsHTML(true);
    $mail->msgHTML($mensagem);

    $mail->send();
}

require 'config.php';

$result = mysqli_query($con, "SELECT COUNT(*) FROM desafio WHERE usuario = '{$usuario}'");
$row = mysqli_fetch_array($result);

$result2 = mysqli_query($con, "SELECT COUNT(*) FROM desafio WHERE email = '{$email}'");
$row2 = mysqli_fetch_array($result2);

if ($row[0] > 0) {
    $response_array = 'error';
    echo json_encode($response_array);
} else if ($row2[0] > 0) {
    $response_array = 'error';
    echo json_encode($response_array);
} else {
    email($email, $token);
    mysqli_query($con, "INSERT INTO desafio (nome, sobre_nome, email, usuario, senha, hr_token, token, status_token) VALUES('$nome', '$sobre_nome', '$email', '$usuario', '$senha', '$hr', '$token', '$status_token')");
    $response_array = 'success';
    echo json_encode($response_array);
}
